
const readline = require('node:readline');
const { stdin: input, stdout: output } = require('node:process');

const rl = readline.createInterface({ input, output });


let secretNumber = 6;


function checkGuess(num) {
    if (Number(num) > secretNumber) {
        console.log("Too high.")
        return false;
    }
    if (Number(num) < secretNumber) {
        console.log("Too small")
        return false;
    }

    if (Number(num) === secretNumber) {
        console.log("Correct!")
        return true;
    }
}

function askGuess() {
    rl.question('Enter a guess: ', (answer) => {
        let res = checkGuess(answer)
        if (res) {
            console.log("You win!")

            rl.close();

        }   else {
            askGuess();
        }
    });

}


askGuess();
